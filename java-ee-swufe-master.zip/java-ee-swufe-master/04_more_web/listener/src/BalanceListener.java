public interface BalanceListener {
    void onBalanceChange(BalanceEvent balanceEvent);
}
