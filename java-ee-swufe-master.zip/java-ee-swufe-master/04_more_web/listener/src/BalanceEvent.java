public class BalanceEvent {
    private double balance;
    public BalanceEvent(double balance) {
        this.balance = balance;
    }
    public double getBalance() {
        return balance;
    }
}
