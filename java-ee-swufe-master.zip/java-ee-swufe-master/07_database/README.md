Database is one of the most important courses of Computer Science, and it is also essential to web development. 

# Useful links
- [SQL Tutorial](https://www.w3schools.com/sql/default.asp)
