# What is JavaEE
The Java EE platform is built on top of the Java SE platform. The Java EE platform provides an API and runtime environment for developing and running large-scale, multi-tiered, scalable, reliable, and secure network applications.

# Prerequisites and Tools
- Java SE
- Maven
- Git
- IntelliJ IDEA
- Tomcat

# Useful Links
- [Java EE Web Profile vs Java EE Full Platform Profile](https://stackoverflow.com/questions/24239978/)
