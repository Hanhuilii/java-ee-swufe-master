Spring makes programming Java quicker, easier, and safer for everybody, and it has become the world's most popular Java Framework. Spring makes building web applications fast and hassle-free.

# Useful links
- [Spring Quick Start Guide](https://spring.io/quickstart)
- [Inversion of Control vs Dependency Injection](https://stackoverflow.com/questions/6550700)