# Java EE Course at SWUFE
Codes for the Java EE course at SWUFE. 

The textbook mainly includes:
- [Head First Servlets and JSP](https://book.douban.com/subject/3223139/)
- [Spring in Action](https://book.douban.com/subject/24830012/)
